import { MutableRefObject, useLayoutEffect, useRef } from 'react';
import { InputModel } from './useInputModel';
import { setRange } from '../utils/setRange';

interface Config {
  model: InputModel;
  cursorRef: MutableRefObject<HTMLDivElement | null>;
  containerRef: MutableRefObject<HTMLDivElement | null>;
  fakeInputDivRef: MutableRefObject<HTMLDivElement | null>;
}

export function useBlinkingCursorLayout({
  model,
  cursorRef,
  fakeInputDivRef,
  containerRef,
}: Config) {
  const { showBlinkingCursor, selectionRange } = model.getState();
  useLayoutEffect(() => {
    if (
      selectionRange &&
      showBlinkingCursor &&
      cursorRef.current &&
      containerRef.current &&
      fakeInputDivRef.current
    ) {
      const fakeInputRect = fakeInputDivRef.current!.getBoundingClientRect();
      const range = setRange(fakeInputDivRef.current!, selectionRange);
      const rangeRect = range.getBoundingClientRect();
      const left = rangeRect.left - fakeInputRect.left;
      console.log(left)
      cursorRef.current!.style.left = Math.max(0, left) + 'px';
      if (!range.collapsed) {
        // cursorRef.current!.style.width = '0';
        const selection = window.getSelection();
        selection?.removeAllRanges();
        selection?.addRange(range);
      } else {
        // cursorRef.current!.style.removeProperty('width');
      }
    }
  }, [showBlinkingCursor, selectionRange]);
}
