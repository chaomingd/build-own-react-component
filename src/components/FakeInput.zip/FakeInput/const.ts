import EventEmitter from '@/utils/EventEmitter'

export const CLS_PREFIX = 'fake-input'

export const FAKE_INPUT_SIGNAL = new EventEmitter();
