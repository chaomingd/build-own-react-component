import Input from './Input'
import { FakeInputProps } from './type';
import { SearchOutlined } from '@ant-design/icons'


const Search = (props: FakeInputProps) => {
  return (
    <Input {...props} prefix={props.prefix ? props.prefix : <SearchOutlined />} />
  )
}

export default Search;
