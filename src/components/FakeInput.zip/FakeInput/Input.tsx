import { FakeInputProps } from './type';
import { CLS_PREFIX } from './const';
import { InputRef } from 'antd';
import { useInputModel } from './hooks/useInputModel';
import { useSignal } from './hooks/useSignal';
import { forwardRef, useRef } from 'react';
import { useBlinkingCursorLayout } from './hooks/useBlinkingCursorLayout';
import './index.less';
import classNames from 'classnames';
import { usePressEnter } from './hooks/usePressEnter';

const FakeInput = forwardRef<Omit<InputRef, 'input'>, FakeInputProps>(
  (props, ref) => {
    const { prefix, round } = props;
    const cursorRef = useRef<HTMLDivElement | null>(null);
    const containerRef = useRef<HTMLDivElement | null>(null);
    const fakeInputDivRef = useRef<HTMLDivElement | null>(null);
    const model = useInputModel(props);
    const { value, showBlinkingCursor } = model.useGetState();

    useSignal({
      props,
      model,
      fakeInputDivRef,
    });

    useBlinkingCursorLayout({
      model,
      cursorRef,
      containerRef,
      fakeInputDivRef,
    });

    usePressEnter({
      domRef: fakeInputDivRef,
    });

    return (
      <div
        ref={containerRef}
        className={classNames(
          CLS_PREFIX,
          showBlinkingCursor && `${CLS_PREFIX}--focus`,
          round && `${CLS_PREFIX}--round`
        )}
      >
        {prefix && <div className={`${CLS_PREFIX}-prefix`}>{prefix}</div>}
        <div className={`${CLS_PREFIX}-wrapper`}>
          <pre>
            <div
              contentEditable
              suppressContentEditableWarning
              spellCheck={false}
              className={`${CLS_PREFIX}-el`}
              aria-role="input"
              role="input"
              ref={(el) => {
                fakeInputDivRef.current = el;
                if (ref) {
                  if (typeof ref === 'function') {
                    ref(el as InputRef | null);
                  } else {
                    ref!.current = el as InputRef | null;
                  }
                }
              }}
            >
              {value}
            </div>
          </pre>
          {showBlinkingCursor && (
            <div
              ref={cursorRef}
              draggable={false}
              className={`${CLS_PREFIX}-blinking-cursor`}
            />
          )}
        </div>
      </div>
    );
  }
);

export default FakeInput;
